#!/usr/bin/env python3
"""
Simple script to create placeholder PNG icons for the Chrome extension.
"""
from PIL import Image, ImageDraw
import os

def create_icon(size, filename):
    img = Image.new('RGBA', (size, size), color=(0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    for i in range(size):
        for j in range(size):
            ratio_x = i / size
            ratio_y = j / size
            r = int(102 + (118 - 102) * ratio_x)
            g = int(126 + (75 - 126) * ratio_x)
            b = int(234 + (162 - 234) * ratio_x)

            radius = size * 0.2
            if (i < radius and j < radius):
                dist = ((i - radius) ** 2 + (j - radius) ** 2) ** 0.5
                if dist > radius:
                    continue
            elif (i > size - radius and j < radius):
                dist = ((i - (size - radius)) ** 2 + (j - radius) ** 2) ** 0.5
                if dist > radius:
                    continue
            elif (i < radius and j > size - radius):
                dist = ((i - radius) ** 2 + (j - (size - radius)) ** 2) ** 0.5
                if dist > radius:
                    continue
            elif (i > size - radius and j > size - radius):
                dist = ((i - (size - radius)) ** 2 + (j - (size - radius)) ** 2) ** 0.5
                if dist > radius:
                    continue

            img.putpixel((i, j), (r, g, b, 255))

    book_margin = int(size * 0.2)
    book_width = int(size * 0.6)
    book_height = int(size * 0.5)
    book_x = book_margin
    book_y = int(size * 0.25)

    draw.rounded_rectangle(
        [(book_x, book_y), (book_x + book_width, book_y + book_height)],
        radius=int(size * 0.08),
        fill=(255, 255, 255, 230)
    )

    line_width = int(max(1, size * 0.03))
    line_start_x = book_x + int(book_width * 0.15)
    line_end_x = book_x + int(book_width * 0.85)
    line_spacing = int(book_height * 0.22)
    first_line_y = book_y + int(book_height * 0.25)

    for i in range(4):
        y = first_line_y + (i * line_spacing)
        end_x = line_end_x
        if i == 2:
            end_x = line_end_x - int(book_width * 0.2)
        elif i == 3:
            end_x = line_end_x - int(book_width * 0.12)

        draw.line([(line_start_x, y), (end_x, y)], fill=(102, 126, 234, 255), width=line_width)

    icons_dir = os.path.join(os.path.dirname(__file__), 'icons')
    os.makedirs(icons_dir, exist_ok=True)

    filepath = os.path.join(icons_dir, filename)
    img.save(filepath, 'PNG')
    print(f'Created: {filepath}')

if __name__ == '__main__':
    try:
        create_icon(16, 'icon16.png')
        create_icon(48, 'icon48.png')
        create_icon(128, 'icon128.png')
        print('\nAll icons created successfully!')
    except ImportError:
        print('Error: PIL (Pillow) is required. Install it with: pip install Pillow')
    except Exception as e:
        print(f'Error creating icons: {e}')
