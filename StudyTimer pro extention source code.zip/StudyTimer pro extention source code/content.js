/**
 * StudyTimer Pro - Chrome Extension
 * Copyright (c) 2025 Rohit K.S. (rohitks.com.np)
 * All rights reserved.
 * 
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 */

let floatingTimer = null;
let timerInterval = null;

console.log('StudyTimer Pro: Content script loaded');

function createFloatingTimer() {
  if (floatingTimer) return;

  console.log('Creating floating timer element');

  floatingTimer = document.createElement('div');
  floatingTimer.id = 'study-floating-timer';
  floatingTimer.className = 'study-floating-timer';

  floatingTimer.innerHTML = `
    <div class="study-floating-timer-icon">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <path d="M12 6v6l4 2"></path>
      </svg>
    </div>
    <div class="study-floating-timer-time">00:00:00</div>
  `;

  if (document.body) {
    document.body.appendChild(floatingTimer);
    console.log('Floating timer added to body');
  } else {
    console.log('Document body not ready, waiting...');
    document.addEventListener('DOMContentLoaded', () => {
      document.body.appendChild(floatingTimer);
      console.log('Floating timer added to body after DOMContentLoaded');
    });
  }
}

function updateTimerDisplay(time) {
  if (!floatingTimer) return;

  const hours = Math.floor(time / 3600);
  const minutes = Math.floor((time % 3600) / 60);
  const seconds = time % 60;
  const timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const timeElement = floatingTimer.querySelector('.study-floating-timer-time');
  if (timeElement) {
    timeElement.textContent = timeString;
  }
}

function showFloatingTimer(settings) {
  if (!floatingTimer) {
    createFloatingTimer();
  }

  floatingTimer.classList.remove('left', 'right');
  floatingTimer.classList.add(settings.position || 'left');
  floatingTimer.classList.add('active');
}

function hideFloatingTimer() {
  if (floatingTimer) {
    floatingTimer.classList.remove('active');
  }
}

function removeFloatingTimer() {
  if (floatingTimer) {
    floatingTimer.remove();
    floatingTimer = null;
  }
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Content script received message:', message.type);

  if (message.type === 'TIMER_START') {
    console.log('Starting timer with settings:', message.settings);
    if (message.settings.enabled) {
      showFloatingTimer(message.settings);
      updateTimerDisplay(message.time || 0);
    }
  } else if (message.type === 'TIMER_UPDATE') {
    updateTimerDisplay(message.time);
    // If a reset occurred, flash the timer to indicate fresh start
    if (message.resetOccurred && floatingTimer) {
      floatingTimer.classList.add('reset-flash');
      setTimeout(() => {
        floatingTimer.classList.remove('reset-flash');
      }, 1000);
    }
  } else if (message.type === 'TIMER_STOP') {
    console.log('Stopping timer');
    hideFloatingTimer();
  } else if (message.type === 'TIMER_SETTINGS_CHANGED') {
    console.log('Settings changed:', message.settings);
    if (message.settings.enabled && floatingTimer && floatingTimer.classList.contains('active')) {
      floatingTimer.classList.remove('left', 'right');
      floatingTimer.classList.add(message.settings.position || 'left');
    } else if (!message.settings.enabled) {
      hideFloatingTimer();
    }
  }
});

function initializeTimer() {
  chrome.storage.local.get(['settings', 'studyData'], (result) => {
    console.log('Initializing timer with state:', result);

    if (result.studyData?.sessionActive && result.settings?.floatingTimer) {
      console.log('Session is active and floating timer enabled');
      createFloatingTimer();
      showFloatingTimer({
        position: result.settings?.floatingTimerPosition || 'left'
      });
      if (result.studyData?.todayStudyTime) {
        updateTimerDisplay(result.studyData.todayStudyTime);
      }
    } else {
      console.log('Timer not shown - sessionActive:', result.studyData?.sessionActive, 'floatingTimer:', result.settings?.floatingTimer);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeTimer);
} else {
  initializeTimer();
}

window.addEventListener('beforeunload', () => {
  removeFloatingTimer();
});
