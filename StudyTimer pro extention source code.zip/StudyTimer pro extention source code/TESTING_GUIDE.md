# Complete Testing Guide for Floating Timer

Follow these exact steps to get the floating timer working on all browser tabs:

## Step 1: Reload the Extension

1. Open Chrome and type `chrome://extensions/` in the address bar
2. Make sure "Developer mode" is ON (toggle in top-right corner)
3. Find "RohitKS Study Assistant"
4. Click the **RELOAD** button (circular arrow icon)
5. You should see a popup saying it needs additional permissions
6. Click **Accept** or **Allow** to grant permissions for all URLs

## Step 2: Close ALL Chrome Tabs

1. Close every single Chrome tab you have open
2. Open a brand new tab (any website like google.com)

## Step 3: Test the Timer

1. Click the extension icon (puzzle piece icon in toolbar → RohitKS Study Assistant)
2. Click the **Settings** icon (gear icon)
3. Make sure **"Show Floating Timer"** toggle is ON (should be blue/green)
4. Go back to the main screen (click back arrow)
5. Click **"Start Session"** button

## Expected Result

You should now see a small floating timer at the **bottom-left** of your browser window showing:
- A clock icon (blue/purple gradient)
- Time in format: 00:00:00

The timer should:
- Appear on ALL browser tabs
- Update every second
- Stay visible when you switch tabs
- Stay visible when you navigate to different websites
- Be draggable/movable (hover to see animation)

## Troubleshooting

### Timer Not Showing?

**Test 1: Check Console**
1. On any webpage, press `F12` to open DevTools
2. Click the **Console** tab
3. Look for these messages:
   - `RohitKS Study Assistant: Content script loaded`
   - `Initializing timer with state:`
   - `Session is active and floating timer enabled`
   - `Creating floating timer element`

If you DON'T see these messages:
- Content script isn't loading → Reload extension and close/reopen tabs

**Test 2: Check Element**
1. With DevTools open, click the **Elements** tab
2. Press `Ctrl+F` (or `Cmd+F` on Mac)
3. Search for: `study-floating-timer`
4. If found, check if it has the class `active`

If element is found but no `active` class:
- Settings not properly saved → Toggle "Show Floating Timer" off and on again

**Test 3: Check Permissions**
1. Go to `chrome://extensions/`
2. Find "RohitKS Study Assistant"
3. Click **Details**
4. Under "Permissions", you should see: "Read and change all your data on all websites"

If you don't see this permission:
- The extension needs to be reloaded and permissions accepted

### Timer Only Shows in Popup?

This means the content script isn't injected into regular web pages. Solution:
1. Go to `chrome://extensions/`
2. **Remove** the extension completely
3. Click **Load unpacked** again
4. Select the project folder
5. Accept the permission popup
6. Open a new tab and test again

### Timer Shows But Wrong Position?

1. Click extension icon → Settings
2. Change **Floating Timer Position** from Left to Right (or vice versa)
3. Timer should move to the other side

## Quick Reset

If nothing works:
1. Open extension popup
2. Click Settings
3. Click "Reset All Data" at the bottom
4. Reload the extension
5. Close all tabs
6. Open new tab and start fresh
