# Quick Start Guide

Get your Advanced Reading Assistant up and running in 5 minutes!

## Step 1: Create Icons (2 minutes)

The extension needs three icon files. Choose the easiest method:

### Method A: Use the HTML Generator (Easiest)
1. Navigate to the `icons/` folder
2. Open `generate_icons.html` in Chrome
3. Three PNG files will download automatically
4. Move them to the `icons/` folder

### Method B: Create Simple Placeholders (Fastest)
1. Open any image editor (Paint, GIMP, or online editor)
2. Create three square images with these sizes:
   - 16x16 pixels (name it `icon16.png`)
   - 48x48 pixels (name it `icon48.png`)
   - 128x128 pixels (name it `icon128.png`)
3. Fill them with any color (purple/blue recommended)
4. Save them in the `icons/` folder

## Step 2: Load Extension in Chrome (1 minute)

1. Open Chrome and go to: `chrome://extensions/`
2. Toggle **"Developer mode"** ON (top-right corner)
3. Click **"Load unpacked"**
4. Select the project folder (where `manifest.json` is located)
5. Click **"Select Folder"**

✅ The extension icon should now appear in your toolbar!

## Step 3: First Time Setup (2 minutes)

### Configure Your Preferences
1. Click the extension icon in your toolbar
2. Click the **⚙️ Settings** icon
3. Set your preferences:
   - **Default Reading Site**: Leave as is or change
   - **Font Size**: Adjust to your preference (default: 16px)
   - **Theme**: Choose Light, Dark, or Sepia
   - **Daily Goal**: Set your reading target (default: 30 min)

4. Click **"Save Settings"**

### Test the Features
1. **Reading Mode**:
   - Visit any article or blog post
   - Click the extension icon
   - Click "Reading Mode"
   - Enjoy distraction-free reading!

2. **Text-to-Speech**:
   - While in reading mode, click the 🔊 button
   - Or use keyboard shortcut: `Ctrl+Shift+S`

3. **Practice Quiz**:
   - Click the extension icon
   - Click "Start Practice Quiz"
   - Answer 10 questions
   - View your results!

## Common First-Time Issues

### "Could not load icon" Error
- **Solution**: Make sure all three icon files exist in the `icons/` folder
- Check that they're named exactly: `icon16.png`, `icon48.png`, `icon128.png`

### Extension Not Appearing
- **Solution**: After loading, click the puzzle piece icon in Chrome toolbar
- Pin the extension for easy access

### Features Not Working on Current Page
- **Solution**: Refresh the page after installing the extension
- Some sites may have restrictions (very rare)

### Notifications Not Showing
- **Solution**: Grant notification permissions when prompted
- Check Chrome settings: Settings → Privacy → Site Settings → Notifications

## Pro Tips

1. **Keyboard Shortcuts**:
   - `Ctrl+Shift+R`: Toggle Reading Mode
   - `Ctrl+Shift+S`: Toggle Text-to-Speech

2. **Right-Click Menu**:
   - Select any text and right-click
   - Choose "Read Selected Text" for instant TTS

3. **Daily Routine**:
   - Set a daily reminder in the popup
   - Track your reading time each day
   - Complete one quiz per day

4. **Customization**:
   - Experiment with different themes
   - Adjust font sizes while reading
   - Find your perfect TTS speed

5. **Data Backup**:
   - Export your data regularly from Settings
   - Keep backups of your quiz progress

## What to Try First

### For Readers:
1. Enable Reading Mode on your favorite blog
2. Try the Dark theme for night reading
3. Experiment with TTS while multitasking
4. Set up auto-reading mode for read.rohitks.com.np

### For Students:
1. Start with an Easy difficulty quiz
2. Set a daily study reminder
3. Track your progress over time
4. Try Mixed difficulty once comfortable

### For Power Users:
1. Set up custom keyboard shortcuts
2. Exclude specific sites from reading mode
3. Export your data regularly
4. Use context menu for quick actions

## Next Steps

- Read the full [README.md](README.md) for detailed features
- Check [FEATURES.md](FEATURES.md) for complete feature list
- Review [INSTALLATION.md](INSTALLATION.md) for advanced setup
- Explore all settings to find your perfect configuration

## Getting Help

**Extension not working as expected?**
1. Check the [README.md](README.md) Troubleshooting section
2. Verify all files are in place
3. Reload the extension from `chrome://extensions/`
4. Refresh your web pages

**Want to learn more?**
- Explore all the settings options
- Try different combinations of features
- Experiment with quiz difficulties

---

**Estimated Setup Time**: 5 minutes
**Difficulty**: Easy
**You're Ready**: Start reading better today!
