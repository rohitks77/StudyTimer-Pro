# StudyTimer Pro - Professional Icon Generator
Add-Type -AssemblyName System.Drawing

function New-StudyTimerIcon {
    param([int]$Size, [string]$OutputPath)
    
    $bitmap = New-Object System.Drawing.Bitmap($Size, $Size)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    
    # Background gradient (blue to purple)
    $rect = New-Object System.Drawing.Rectangle(0, 0, $Size, $Size)
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect,
        [System.Drawing.Color]::FromArgb(59, 130, 246),
        [System.Drawing.Color]::FromArgb(139, 92, 246),
        45
    )
    
    # Draw rounded rectangle background
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $radius = [int]($Size * 0.22)
    $path.AddArc(0, 0, $radius * 2, $radius * 2, 180, 90)
    $path.AddArc($Size - $radius * 2, 0, $radius * 2, $radius * 2, 270, 90)
    $path.AddArc($Size - $radius * 2, $Size - $radius * 2, $radius * 2, $radius * 2, 0, 90)
    $path.AddArc(0, $Size - $radius * 2, $radius * 2, $radius * 2, 90, 90)
    $path.CloseFigure()
    $graphics.FillPath($brush, $path)
    
    # Clock circle
    $centerX = $Size / 2
    $centerY = $Size / 2
    $clockRadius = [int]($Size * 0.35)
    
    # White clock face
    $whiteBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $graphics.FillEllipse($whiteBrush, $centerX - $clockRadius, $centerY - $clockRadius, $clockRadius * 2, $clockRadius * 2)
    
    # Clock border
    $borderPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(99, 102, 241), [int]($Size * 0.04))
    $graphics.DrawEllipse($borderPen, $centerX - $clockRadius, $centerY - $clockRadius, $clockRadius * 2, $clockRadius * 2)
    
    # Hour markers
    $markerBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(99, 102, 241))
    $markerRadius = [int]($Size * 0.025)
    $markerDist = $clockRadius * 0.75
    
    # 12, 3, 6, 9 positions
    $positions = @(0, 90, 180, 270)
    foreach ($angle in $positions) {
        $rad = [Math]::PI * $angle / 180 - [Math]::PI / 2
        $x = $centerX + [Math]::Cos($rad) * $markerDist - $markerRadius
        $y = $centerY + [Math]::Sin($rad) * $markerDist - $markerRadius
        $graphics.FillEllipse($markerBrush, $x, $y, $markerRadius * 2, $markerRadius * 2)
    }
    
    # Center dot
    $centerDot = [int]($Size * 0.035)
    $graphics.FillEllipse($markerBrush, $centerX - $centerDot, $centerY - $centerDot, $centerDot * 2, $centerDot * 2)
    
    # Hour hand (10 o'clock position)
    $hourAngle = [Math]::PI * 300 / 180 - [Math]::PI / 2
    $hourLength = $clockRadius * 0.45
    $hourPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(99, 102, 241), [int]($Size * 0.06))
    $hourPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $hourPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $graphics.DrawLine($hourPen, $centerX, $centerY, 
        $centerX + [Math]::Cos($hourAngle) * $hourLength,
        $centerY + [Math]::Sin($hourAngle) * $hourLength)
    
    # Minute hand (2 o'clock position)
    $minuteAngle = [Math]::PI * 60 / 180 - [Math]::PI / 2
    $minuteLength = $clockRadius * 0.65
    $minutePen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(139, 92, 246), [int]($Size * 0.045))
    $minutePen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $minutePen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $graphics.DrawLine($minutePen, $centerX, $centerY,
        $centerX + [Math]::Cos($minuteAngle) * $minuteLength,
        $centerY + [Math]::Sin($minuteAngle) * $minuteLength)
    
    # Save
    $graphics.Dispose()
    $bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bitmap.Dispose()
    
    Write-Host "✓ Created $OutputPath" -ForegroundColor Green
}

# Generate all three icon sizes
$iconPath = Split-Path -Parent $PSCommandPath
New-StudyTimerIcon -Size 16 -OutputPath "$iconPath\icon16.png"
New-StudyTimerIcon -Size 48 -OutputPath "$iconPath\icon48.png"
New-StudyTimerIcon -Size 128 -OutputPath "$iconPath\icon128.png"

Write-Host "`n✅ All icons generated successfully!" -ForegroundColor Cyan
Write-Host "The extension is ready to use!" -ForegroundColor Cyan
