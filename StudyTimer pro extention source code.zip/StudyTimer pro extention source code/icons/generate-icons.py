from PIL import Image, ImageDraw
import os

def create_icon(size):
    # Create image with higher resolution for better quality, then downscale
    scale = 4  # 4x supersampling for smooth edges
    big_size = size * scale
    img = Image.new('RGBA', (big_size, big_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw rounded rectangle background with richer gradient
    radius = int(big_size * 0.19)
    
    # Stronger, deeper gradient for better contrast
    for i in range(big_size):
        for j in range(big_size):
            # Check if point is within rounded rectangle
            if ((i < radius and j < radius and (i-radius)**2 + (j-radius)**2 > radius**2) or
                (i > big_size-radius and j < radius and (i-big_size+radius)**2 + (j-radius)**2 > radius**2) or
                (i < radius and j > big_size-radius and (i-radius)**2 + (j-big_size+radius)**2 > radius**2) or
                (i > big_size-radius and j > big_size-radius and (i-big_size+radius)**2 + (j-big_size+radius)**2 > radius**2)):
                continue
            
            # Deeper, richer purple to indigo gradient (better contrast)
            progress = (i + j) / (2 * big_size)
            r = int(88 + (99 - 88) * progress)
            g = int(86 + (102 - 86) * progress)
            b = int(214 + (241 - 214) * progress)
            img.putpixel((i, j), (r, g, b, 255))
    
    # Book dimensions (scaled up)
    book_x = int(big_size * 0.19)
    book_y = int(big_size * 0.25)
    book_width = int(big_size * 0.625)
    book_height = int(big_size * 0.5)
    book_radius = int(big_size * 0.078)
    
    # Add subtle shadow behind book for depth
    shadow_offset = int(big_size * 0.015)
    draw.rounded_rectangle(
        [book_x + shadow_offset, book_y + shadow_offset, 
         book_x + book_width + shadow_offset, book_y + book_height + shadow_offset],
        radius=book_radius,
        fill=(0, 0, 0, 60)
    )
    
    # Draw crisp white book shape (fully opaque for maximum contrast)
    draw.rounded_rectangle(
        [book_x, book_y, book_x + book_width, book_y + book_height],
        radius=book_radius,
        fill=(255, 255, 255, 255)
    )
    
    # Draw text lines on book with much darker color for better readability
    line_color = (67, 56, 202, 255)  # Darker indigo - much better contrast on white
    line_width = max(3, int(big_size * 0.025))
    
    line_start_x = book_x + int(book_width * 0.15)
    line_spacing = int(book_height * 0.22)
    first_line_y = book_y + int(book_height * 0.25)
    
    # Draw 4 lines with rounded caps
    for i in range(4):
        y = first_line_y + (i * line_spacing)
        # Vary line lengths
        if i == 2:
            line_end_x = book_x + int(book_width * 0.65)
        elif i == 3:
            line_end_x = book_x + int(book_width * 0.75)
        else:
            line_end_x = book_x + int(book_width * 0.85)
        
        # Draw thick rounded lines
        draw.line([line_start_x, y, line_end_x, y], 
                 fill=line_color, width=line_width)
        # Add circles at ends for rounded caps
        cap_radius = line_width // 2
        draw.ellipse([line_start_x - cap_radius, y - cap_radius,
                     line_start_x + cap_radius, y + cap_radius],
                    fill=line_color)
        draw.ellipse([line_end_x - cap_radius, y - cap_radius,
                     line_end_x + cap_radius, y + cap_radius],
                    fill=line_color)
    
    # Downscale with high-quality resampling (LANCZOS for best quality)
    img = img.resize((size, size), Image.Resampling.LANCZOS)
    
    return img

# Generate icons
script_dir = os.path.dirname(os.path.abspath(__file__))
for size in [16, 48, 128]:
    icon = create_icon(size)
    output_path = os.path.join(script_dir, f'icon{size}.png')
    icon.save(output_path, 'PNG')
    print(f'✓ Created icon{size}.png (high contrast)')

print('\n✅ All icons generated successfully!')
print('🎨 High contrast design - Darker background, pure white book, dark lines!')
