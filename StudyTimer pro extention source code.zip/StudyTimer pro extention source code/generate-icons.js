const fs = require('fs');
const path = require('path');

function createSimplePNG(width, height, filename) {
  const canvas = `
<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="${width}" height="${height}" rx="${width * 0.2}" fill="url(#grad)"/>
  <g transform="translate(${width * 0.2}, ${height * 0.25})">
    <rect width="${width * 0.6}" height="${height * 0.5}" rx="${width * 0.08}" fill="white" opacity="0.9"/>
    <line x1="${width * 0.1}" y1="${height * 0.12}" x2="${width * 0.5}" y2="${height * 0.12}"
          stroke="url(#grad)" stroke-width="${Math.max(1, width * 0.03)}" stroke-linecap="round"/>
    <line x1="${width * 0.1}" y1="${height * 0.22}" x2="${width * 0.5}" y2="${height * 0.22}"
          stroke="url(#grad)" stroke-width="${Math.max(1, width * 0.03)}" stroke-linecap="round"/>
    <line x1="${width * 0.1}" y1="${height * 0.32}" x2="${width * 0.42}" y2="${height * 0.32}"
          stroke="url(#grad)" stroke-width="${Math.max(1, width * 0.03)}" stroke-linecap="round"/>
    <line x1="${width * 0.1}" y1="${height * 0.42}" x2="${width * 0.46}" y2="${height * 0.42}"
          stroke="url(#grad)" stroke-width="${Math.max(1, width * 0.03)}" stroke-linecap="round"/>
  </g>
</svg>`;

  fs.writeFileSync(path.join(__dirname, 'icons', filename.replace('.png', '.svg')), canvas);
  console.log(`Created SVG icon: ${filename.replace('.png', '.svg')}`);
}

const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir);
}

createSimplePNG(16, 16, 'icon16.png');
createSimplePNG(48, 48, 'icon48.png');
createSimplePNG(128, 128, 'icon128.png');

console.log('\nIcon SVG files created successfully!');
console.log('To convert to PNG, open each SVG file in a browser or image editor and export as PNG.');
console.log('Or use the generate_icons.html file in the icons folder.');
