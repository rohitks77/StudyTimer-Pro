# Advanced Reading Assistant - Project Structure

## Core Extension Files

### Manifest & Configuration
- `manifest.json` - Chrome extension configuration (Manifest V3)
- `.gitignore` - Git ignore rules for the project

### Popup Interface (Extension Icon Click)
- `popup.html` - Main popup interface structure
- `popup.css` - Popup styling with gradient theme
- `popup.js` - Popup functionality and controls

### Settings/Options Page
- `options.html` - Comprehensive settings page structure
- `options.css` - Settings page styling
- `options.js` - Settings management and storage

### Background Service Worker
- `background.js` - Background tasks, notifications, alarms, context menus

### Content Scripts (Injected into Web Pages)
- `content.js` - Reading mode, TTS, page manipulation
- `content.css` - Reading mode styles and themes

### Quiz/Preparation Module
- `quiz.html` - Computer operator quiz interface
- `quiz.css` - Quiz page styling
- `quiz.js` - Quiz logic, questions, and scoring

## Icon Files (Required - User Must Create)

### icons/ Directory
- `icon16.png` - 16x16 toolbar icon (REQUIRED)
- `icon48.png` - 48x48 management icon (REQUIRED)
- `icon128.png` - 128x128 webstore icon (REQUIRED)
- `icon.svg` - SVG source for icons
- `generate_icons.html` - Automated icon generator
- `ICONS_README.txt` - Icon creation instructions
- `PLACEHOLDER_ICONS.txt` - Important notice about icons

## Documentation Files

### User Documentation
- `README.md` - Comprehensive project documentation
- `QUICK_START.md` - 5-minute setup guide
- `INSTALLATION.md` - Detailed installation instructions
- `FEATURES.md` - Complete feature list (100+ features)
- `PROJECT_STRUCTURE.md` - This file

### Developer Files
- `generate-icons.js` - Node.js icon generator (requires updating for ES modules)
- `create-icons.py` - Python icon generator (requires PIL/Pillow)

## Additional Project Files (Can be Ignored)

### React/Vite Files (Not Used by Extension)
- `src/` - Original React source (not needed for extension)
- `index.html` - Vite dev server entry (not used)
- `vite.config.ts` - Vite configuration (not used)
- Various TypeScript configs (not used for extension)

### Build & Development
- `node_modules/` - Dependencies (not included in extension)
- `package.json` - Project dependencies
- `package-lock.json` - Lock file
- `eslint.config.js` - Linting configuration
- `tailwind.config.js` - Tailwind CSS config
- `postcss.config.js` - PostCSS config

## File Sizes

### Total Extension Size (Without Icons)
- Core JavaScript: ~50 KB
- HTML Files: ~15 KB
- CSS Files: ~20 KB
- Manifest: ~1.5 KB
- **Total**: ~86.5 KB

### With Documentation
- Documentation: ~30 KB
- **Grand Total**: ~116.5 KB

### Very Lightweight Extension!

## Extension Loading Structure

When Chrome loads the extension:

1. **manifest.json** - Defines all permissions and files
2. **background.js** - Starts immediately, runs continuously
3. **Popup files** - Loaded when icon is clicked
4. **Options page** - Loaded when settings are opened
5. **Content scripts** - Injected into every web page
6. **Quiz page** - Loaded when user starts a quiz

## Data Flow

### Local Storage Structure
```javascript
{
  settings: {
    // All user preferences
    readingSite, fontSize, theme, etc.
  },
  stats: {
    // Daily reading statistics
    readingTime, pagesRead, lastReset
  },
  quizProgress: {
    // Quiz completion tracking
    completed, total
  },
  quizHistory: [
    // Array of past quiz results
    { date, score, percentage, timeTaken }
  ]
}
```

### Message Passing
- **Popup → Background**: Settings updates, stats requests
- **Background → Content**: Reading mode toggle, TTS control
- **Content → Background**: Stats updates, page events
- **Options → Background**: Settings changes, alarm setup

## Key Features Implementation

### Reading Mode
- **Trigger**: popup.js or keyboard shortcut
- **Execution**: content.js manipulates DOM
- **Styling**: content.css applies themes

### Text-to-Speech
- **Trigger**: popup.js or content script button
- **Execution**: content.js uses Web Speech API
- **Settings**: Stored in local storage

### Notifications
- **Trigger**: Alarms in background.js
- **Creation**: Chrome notifications API
- **Settings**: User preferences control

### Quizzes
- **Interface**: quiz.html standalone page
- **Questions**: Hardcoded in quiz.js
- **Storage**: Results saved to local storage

### Statistics
- **Collection**: background.js tracks time
- **Display**: popup.js shows daily stats
- **Export**: options.js handles data export

## Browser APIs Used

- **chrome.storage** - Local data persistence
- **chrome.notifications** - User notifications
- **chrome.alarms** - Scheduled events
- **chrome.contextMenus** - Right-click options
- **chrome.tabs** - Tab management
- **chrome.scripting** - Content script injection
- **chrome.commands** - Keyboard shortcuts
- **speechSynthesis** - Text-to-speech (Web API)

## Security & Privacy

### No External Connections
- All code runs locally
- No analytics or tracking
- No external API calls
- No data collection

### Local Storage Only
- Chrome's local storage API
- Data never leaves device
- User can export/import
- Can be cleared anytime

### Permissions Justification
- **storage** - Save settings and stats
- **notifications** - Study reminders
- **alarms** - Scheduled notifications
- **activeTab** - Reading mode on current page
- **scripting** - Inject content scripts
- **tabs** - Open reading site
- **contextMenus** - Right-click features

## Installation Requirements

### Minimum Requirements
1. Chrome 88+ or Edge 88+
2. Three icon PNG files (16, 48, 128px)
3. Developer mode enabled

### Optional Requirements
- Python + PIL (for icon generation script)
- Node.js (for ES module icon script)
- Web browser (for HTML icon generator)

## File Dependencies

### Critical Files (Extension Won't Load Without)
- manifest.json
- background.js
- popup.html, popup.js, popup.css
- content.js, content.css
- options.html, options.js, options.css
- quiz.html, quiz.js, quiz.css
- icon16.png, icon48.png, icon128.png (USER MUST CREATE)

### Optional Files (Nice to Have)
- README.md and documentation
- Icon generators
- Git ignore file

### Unused Files (Can Be Deleted)
- src/ directory
- index.html (Vite entry point)
- vite.config.ts
- TypeScript configs
- React source files

## Customization Points

### Easy to Customize
1. **Default Reading Site** - Change in manifest.json and settings
2. **Theme Colors** - Modify CSS gradient values
3. **Quiz Questions** - Add to quiz.js questionBank
4. **Default Settings** - Update getDefaultSettings() functions
5. **Extension Name** - Change in manifest.json

### Moderate Customization
1. **Add New Features** - Extend existing files
2. **New Themes** - Add to options and content.css
3. **More Statistics** - Expand stats tracking
4. **Custom Shortcuts** - Add to manifest commands

### Advanced Customization
1. **New Quiz Types** - Create additional quiz modules
2. **Cloud Sync** - Add backend integration
3. **PDF Support** - Add PDF.js library
4. **OCR Features** - Integrate Tesseract.js

## Testing Checklist

Before using the extension:

- [ ] Icons created and placed in icons/ folder
- [ ] Extension loaded in chrome://extensions/
- [ ] No errors in extension page
- [ ] Popup opens when icon clicked
- [ ] Settings page accessible
- [ ] Reading mode works on test page
- [ ] TTS functionality works
- [ ] Quiz loads and functions
- [ ] Notifications appear
- [ ] Data persists after browser restart

## Troubleshooting

### Extension Won't Load
→ Check icon files exist
→ Verify manifest.json is valid
→ Look for syntax errors in JavaScript

### Features Don't Work
→ Refresh web pages after loading
→ Check browser console for errors
→ Verify permissions granted

### Data Not Saving
→ Check storage permissions
→ Try export/import feature
→ Clear and reload extension

---

**Total Files**: 30+
**Lines of Code**: ~1,500
**Development Time**: Full-featured extension
**Maintenance**: Easy to understand and modify
