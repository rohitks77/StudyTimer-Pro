# How to Export This Chrome Extension

## Method 1: Download ZIP Package

### Create a Clean Package
```bash
# Navigate to project directory
cd /tmp/cc-agent/61760787/project

# Create ZIP excluding unnecessary files
zip -r ../reading-assistant-extension.zip . \
  -x "node_modules/*" \
  -x "dist/*" \
  -x ".git/*" \
  -x "src/*" \
  -x "*.log" \
  -x ".env"

# ZIP file created at: /tmp/cc-agent/61760787/reading-assistant-extension.zip
```

Then download `reading-assistant-extension.zip` from your environment.

## Method 2: Essential Files Only (Minimal)

If you only want the extension (no docs), copy these files:

### Core Extension Files (Required):
```
manifest.json           - Extension configuration
background.js          - Background service worker
content.js             - Content script (reading mode)
content.css            - Content styles
popup.html             - Popup interface
popup.js               - Popup logic
popup.css              - Popup styles
options.html           - Settings page
options.js             - Settings logic
options.css            - Settings styles
quiz.html              - Quiz interface
quiz.js                - Quiz logic and questions
quiz.css               - Quiz styles
```

### Icons Folder (Required):
```
icons/generate_icons.html   - Icon generator
icons/icon.svg             - SVG icon source
icons/ICONS_README.txt     - Instructions
icons/PLACEHOLDER_ICONS.txt - Important notice
```

**Note**: You must create 3 PNG files (icon16.png, icon48.png, icon128.png) after export.

### Documentation (Recommended):
```
README.md              - Main documentation
QUICK_START.md         - 5-minute setup guide
FEATURES.md            - Complete feature list
INSTALLATION.md        - Installation instructions
FINAL_STEPS.md         - Final setup steps
PROJECT_STRUCTURE.md   - Technical overview
EXPORT_GUIDE.md        - This file
```

## Method 3: Copy-Paste Individual Files

If you can't download, copy the content of each file manually:

1. Create a local folder: `reading-assistant-extension/`
2. Create an `icons/` subfolder
3. Copy each file's content from the environment
4. Paste into new files on your local machine
5. Maintain the same file structure

## Method 4: Git Clone (If Pushed to Repository)

If you've pushed this to GitHub/GitLab:
```bash
git clone <your-repository-url>
cd reading-assistant-extension
```

## After Export - Next Steps

### 1. Verify Files
Check that you have all required files:
```bash
# In your local folder
ls -la

# Should see:
# manifest.json, background.js, content.js/css,
# popup files, options files, quiz files, icons/ folder
```

### 2. Create Icons (REQUIRED)
```bash
# Open in browser
icons/generate_icons.html

# Or create manually (16x16, 48x48, 128x128 PNG files)
```

### 3. Load in Chrome
```
1. Open chrome://extensions/
2. Enable "Developer mode"
3. Click "Load unpacked"
4. Select your exported folder
5. Done!
```

## What NOT to Export

These files/folders are not needed for the extension:

- `node_modules/` - Dependencies (too large, not needed)
- `dist/` - Vite build output (not used by extension)
- `src/` - React source (not used by extension)
- `.git/` - Git history (optional)
- `.env` - Environment file (contains secrets)
- `*.log` - Log files
- `package-lock.json` - Optional (only if you want to run npm)

## Package Sizes

- **Minimal Extension Only**: ~90 KB (13 files)
- **With Documentation**: ~120 KB (19 files)
- **With Node Modules**: ~50 MB (not recommended)
- **Complete Package**: ~150 KB (recommended)

## Recommended Export Structure

```
reading-assistant-extension/
├── manifest.json
├── background.js
├── content.js
├── content.css
├── popup.html
├── popup.js
├── popup.css
├── options.html
├── options.js
├── options.css
├── quiz.html
├── quiz.js
├── quiz.css
├── icons/
│   ├── generate_icons.html
│   ├── icon.svg
│   ├── ICONS_README.txt
│   └── PLACEHOLDER_ICONS.txt
├── README.md
├── QUICK_START.md
├── FEATURES.md
├── INSTALLATION.md
├── FINAL_STEPS.md
└── PROJECT_STRUCTURE.md
```

## Sharing the Extension

### For Personal Use
- Export as described above
- Keep locally
- Load as unpacked extension

### For Team/Friends
- Create ZIP with documentation
- Share via email/cloud storage
- Include QUICK_START.md for easy setup

### For Public Distribution
- Consider Chrome Web Store
- Create proper icons/screenshots
- Add privacy policy
- Package as .crx file

## Troubleshooting Export

**Problem**: ZIP too large
**Solution**: Exclude node_modules/ and dist/

**Problem**: Missing files after export
**Solution**: Check the essential files list above

**Problem**: Extension won't load after export
**Solution**: Verify manifest.json and all .js files are present

**Problem**: Icons not working
**Solution**: Create the 3 PNG files (see FINAL_STEPS.md)

## Quick Export Commands

### Minimal Package (Extension Only)
```bash
zip -r extension-minimal.zip \
  manifest.json \
  background.js \
  content.* \
  popup.* \
  options.* \
  quiz.* \
  icons/
```

### Complete Package (With Docs)
```bash
zip -r extension-complete.zip . \
  -x "node_modules/*" \
  -x "dist/*" \
  -x "src/*" \
  -x ".git/*"
```

### Documentation Only
```bash
zip -r extension-docs.zip \
  README.md \
  QUICK_START.md \
  FEATURES.md \
  INSTALLATION.md \
  FINAL_STEPS.md \
  PROJECT_STRUCTURE.md \
  EXPORT_GUIDE.md
```

---

**Need Help?** Check QUICK_START.md for setup instructions after export.

**Ready to Use?** Follow FINAL_STEPS.md to complete the setup.
