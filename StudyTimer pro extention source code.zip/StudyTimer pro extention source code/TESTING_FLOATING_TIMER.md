# Testing the Floating Timer

The floating timer should now appear on all Chrome tabs when you have an active study session.

## Installation Steps

1. **Reload the Extension**
   - Open Chrome and go to `chrome://extensions/`
   - Find "RohitKS Study Assistant"
   - Click the **Reload** button (circular arrow icon)

2. **Refresh All Open Tabs**
   - After reloading the extension, refresh all your open Chrome tabs (Ctrl+R or Cmd+R)
   - This ensures the content script is injected into existing pages

3. **Enable the Floating Timer**
   - Click the extension icon
   - Go to Settings (gear icon)
   - Make sure "Show Floating Timer" toggle is **ON**

4. **Start a Study Session**
   - Click "Start Session" button in the extension popup
   - The timer should now appear at the bottom-left (or bottom-right) of ALL Chrome tabs

## Debugging

If the timer doesn't appear, open the browser console on any page:

1. Press `F12` or right-click → "Inspect"
2. Go to the **Console** tab
3. Look for these messages:
   - `RohitKS Study Assistant: Content script loaded`
   - `Initializing timer with state:` (shows current settings)
   - `Session is active and floating timer enabled` (if session is running)

### Common Issues

**Timer not showing:**
- Check console for error messages
- Verify "Show Floating Timer" is enabled in settings
- Make sure you've started a study session
- Try refreshing the page after starting the session

**Timer only in popup:**
- Extension needs to be reloaded after adding content scripts
- Existing tabs need to be refreshed

**Timer position:**
- Use Settings → Floating Timer Position to change between left/right

## Expected Behavior

✅ Timer appears on all tabs when session is active
✅ Timer updates every second across all tabs
✅ Timer persists when navigating to new pages
✅ Timer respects settings (enabled/disabled, position)
✅ Timer automatically appears on newly opened tabs
