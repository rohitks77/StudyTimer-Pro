# Installation Guide

## Creating Extension Icons

The extension requires three icon files in the `icons/` directory. Since we can't generate PNG files directly, you have two options:

### Option 1: Use the Icon Generator HTML (Recommended)

1. Open `icons/generate_icons.html` in your browser
2. The icons will be automatically downloaded as:
   - `icon16.png`
   - `icon48.png`
   - `icon128.png`
3. Move these files to the `icons/` folder

### Option 2: Create Simple Placeholder Icons

Create three simple colored square PNG files:
- `icons/icon16.png` (16x16 pixels)
- `icons/icon48.png` (48x48 pixels)
- `icons/icon128.png` (128x128 pixels)

You can use any image editor (Paint, Photoshop, GIMP, etc.) to create simple colored squares.

### Option 3: Use the SVG Icon

The `icons/icon.svg` file contains a vector icon. You can:
1. Open it in a vector editor (Inkscape, Adobe Illustrator)
2. Export it as PNG at sizes: 16x16, 48x48, 128x128
3. Save as `icon16.png`, `icon48.png`, `icon128.png`

## Loading the Extension in Chrome

Once you have the icons in place:

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top-right corner)
3. Click "Load unpacked"
4. Select the project folder (the folder containing `manifest.json`)
5. The extension should now appear in your toolbar

## Troubleshooting

### "Could not load icon" Error
- Make sure all three icon files exist in the `icons/` folder
- Verify the files are named correctly: `icon16.png`, `icon48.png`, `icon128.png`
- Ensure the files are valid PNG images

### Extension Not Loading
- Check that `manifest.json` is in the root of the selected folder
- Verify all JavaScript files are present
- Look for errors in the Extensions page

### Features Not Working
- After loading, refresh any open web pages
- Check that you've granted all required permissions
- Try disabling and re-enabling the extension

## Quick Start After Installation

1. Click the extension icon in your toolbar
2. Try the "Reading Mode" on any article or blog post
3. Click "Start Practice Quiz" to test your computer knowledge
4. Open Settings (gear icon) to customize everything
5. Set a study reminder to stay on track

Enjoy your enhanced reading experience!
