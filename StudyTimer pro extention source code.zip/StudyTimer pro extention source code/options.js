/**
 * StudyTimer Pro - Chrome Extension
 * Copyright (c) 2025 Rohit K.S. (rohitks.com.np)
 * All rights reserved.
 * 
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 */

let settings = {};

function getDefaultSettings() {
  return {
    readingSite: 'https://read.rohitks.com.np',
    theme: 'light',
    notifications: true,
    autoReadingMode: true,
    fontSize: 16,
    lineHeight: 1.6,
    maxWidth: 800,
    fontFamily: 'system',
    highlightOnHover: true,
    ttsSpeed: 1.0,
    ttsPitch: 1.0,
    ttsVoice: 'default',
    autoScroll: true,
    dailyGoal: 30,
    quizDifficulty: 'medium',
    dailyReminder: false,
    reminderTime: '09:00',
    contextMenu: true,
    trackingStats: true,
    excludedSites: []
  };
}

async function loadSettings() {
  const result = await chrome.storage.local.get(['settings']);
  const defaults = getDefaultSettings();
  settings = { ...defaults, ...result.settings };
  populateForm();
  loadVoices();
}

function populateForm() {
  document.getElementById('readingSite').value = settings.readingSite;
  document.getElementById('theme').value = settings.theme;
  document.getElementById('notifications').checked = settings.notifications;
  document.getElementById('autoReadingMode').checked = settings.autoReadingMode;

  document.getElementById('fontSize').value = settings.fontSize;
  document.getElementById('fontSizeDisplay').textContent = settings.fontSize + 'px';
  document.getElementById('lineHeight').value = settings.lineHeight;
  document.getElementById('lineHeightDisplay').textContent = settings.lineHeight;
  document.getElementById('maxWidth').value = settings.maxWidth;
  document.getElementById('maxWidthDisplay').textContent = settings.maxWidth + 'px';
  document.getElementById('fontFamily').value = settings.fontFamily;
  document.getElementById('highlightOnHover').checked = settings.highlightOnHover;

  document.getElementById('ttsSpeed').value = settings.ttsSpeed;
  document.getElementById('ttsSpeedDisplay').textContent = settings.ttsSpeed + 'x';
  document.getElementById('ttsPitch').value = settings.ttsPitch;
  document.getElementById('ttsPitchDisplay').textContent = settings.ttsPitch;
  document.getElementById('autoScroll').checked = settings.autoScroll;

  document.getElementById('dailyGoal').value = settings.dailyGoal;
  document.getElementById('quizDifficulty').value = settings.quizDifficulty;
  document.getElementById('dailyReminder').checked = settings.dailyReminder;
  document.getElementById('reminderTime').value = settings.reminderTime;

  document.getElementById('contextMenu').checked = settings.contextMenu;
  document.getElementById('trackingStats').checked = settings.trackingStats;
  document.getElementById('excludedSites').value = settings.excludedSites.join('\n');
}

function loadVoices() {
  const voices = speechSynthesis.getVoices();
  const select = document.getElementById('ttsVoice');

  select.innerHTML = '<option value="default">Default</option>';

  voices.forEach((voice, index) => {
    const option = document.createElement('option');
    option.value = index;
    option.textContent = `${voice.name} (${voice.lang})`;
    if (settings.ttsVoice == index) {
      option.selected = true;
    }
    select.appendChild(option);
  });
}

speechSynthesis.onvoiceschanged = loadVoices;

document.getElementById('fontSize').addEventListener('input', (e) => {
  document.getElementById('fontSizeDisplay').textContent = e.target.value + 'px';
});

document.getElementById('lineHeight').addEventListener('input', (e) => {
  document.getElementById('lineHeightDisplay').textContent = e.target.value;
});

document.getElementById('maxWidth').addEventListener('input', (e) => {
  document.getElementById('maxWidthDisplay').textContent = e.target.value + 'px';
});

document.getElementById('ttsSpeed').addEventListener('input', (e) => {
  document.getElementById('ttsSpeedDisplay').textContent = e.target.value + 'x';
});

document.getElementById('ttsPitch').addEventListener('input', (e) => {
  document.getElementById('ttsPitchDisplay').textContent = e.target.value;
});

document.getElementById('testTTS').addEventListener('click', () => {
  const utterance = new SpeechSynthesisUtterance('This is a test of the text to speech feature.');
  const voiceIndex = document.getElementById('ttsVoice').value;

  if (voiceIndex !== 'default') {
    const voices = speechSynthesis.getVoices();
    utterance.voice = voices[voiceIndex];
  }

  utterance.rate = parseFloat(document.getElementById('ttsSpeed').value);
  utterance.pitch = parseFloat(document.getElementById('ttsPitch').value);

  speechSynthesis.cancel();
  speechSynthesis.speak(utterance);
});

document.getElementById('saveSettings').addEventListener('click', async () => {
  settings.readingSite = document.getElementById('readingSite').value;
  settings.theme = document.getElementById('theme').value;
  settings.notifications = document.getElementById('notifications').checked;
  settings.autoReadingMode = document.getElementById('autoReadingMode').checked;

  settings.fontSize = parseInt(document.getElementById('fontSize').value);
  settings.lineHeight = parseFloat(document.getElementById('lineHeight').value);
  settings.maxWidth = parseInt(document.getElementById('maxWidth').value);
  settings.fontFamily = document.getElementById('fontFamily').value;
  settings.highlightOnHover = document.getElementById('highlightOnHover').checked;

  settings.ttsSpeed = parseFloat(document.getElementById('ttsSpeed').value);
  settings.ttsPitch = parseFloat(document.getElementById('ttsPitch').value);
  settings.ttsVoice = document.getElementById('ttsVoice').value;
  settings.autoScroll = document.getElementById('autoScroll').checked;

  settings.dailyGoal = parseInt(document.getElementById('dailyGoal').value);
  settings.quizDifficulty = document.getElementById('quizDifficulty').value;
  settings.dailyReminder = document.getElementById('dailyReminder').checked;
  settings.reminderTime = document.getElementById('reminderTime').value;

  settings.contextMenu = document.getElementById('contextMenu').checked;
  settings.trackingStats = document.getElementById('trackingStats').checked;

  const excludedText = document.getElementById('excludedSites').value;
  settings.excludedSites = excludedText.split('\n').map(s => s.trim()).filter(s => s);

  await chrome.storage.local.set({ settings });

  if (settings.dailyReminder) {
    const [hours, minutes] = settings.reminderTime.split(':');
    const now = new Date();
    const scheduledTime = new Date();
    scheduledTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    if (scheduledTime <= now) {
      scheduledTime.setDate(scheduledTime.getDate() + 1);
    }

    const delayInMinutes = (scheduledTime - now) / (1000 * 60);
    await chrome.alarms.create('dailyReminder', {
      delayInMinutes,
      periodInMinutes: 24 * 60
    });
  } else {
    await chrome.alarms.clear('dailyReminder');
  }

  showMessage('Settings saved successfully!', 'success');

  chrome.runtime.sendMessage({ action: 'settingsUpdated', settings });
});

document.getElementById('resetDefaults').addEventListener('click', async () => {
  if (confirm('Are you sure you want to reset all settings to defaults?')) {
    settings = getDefaultSettings();
    await chrome.storage.local.set({ settings });
    populateForm();
    showMessage('Settings reset to defaults', 'success');
  }
});

document.getElementById('resetStats').addEventListener('click', async () => {
  if (confirm('Are you sure you want to reset all statistics? This cannot be undone.')) {
    await chrome.storage.local.remove(['stats', 'quizProgress', 'readingHistory']);
    showMessage('Statistics reset successfully', 'success');
  }
});

document.getElementById('exportData').addEventListener('click', async () => {
  const data = await chrome.storage.local.get(null);
  const dataStr = JSON.stringify(data, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = `reading-assistant-backup-${Date.now()}.json`;
  a.click();

  URL.revokeObjectURL(url);
  showMessage('Data exported successfully', 'success');
});

document.getElementById('importData').addEventListener('click', () => {
  document.getElementById('importFile').click();
});

document.getElementById('importFile').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const data = JSON.parse(event.target.result);
      await chrome.storage.local.set(data);
      settings = data.settings || getDefaultSettings();
      populateForm();
      showMessage('Data imported successfully', 'success');
    } catch (error) {
      showMessage('Error importing data: Invalid file format', 'error');
    }
  };
  reader.readAsText(file);
});

function showMessage(text, type) {
  const messageEl = document.getElementById('saveMessage');
  messageEl.textContent = text;
  messageEl.className = `save-message show ${type}`;

  setTimeout(() => {
    messageEl.classList.remove('show');
  }, 3000);
}

loadSettings();
