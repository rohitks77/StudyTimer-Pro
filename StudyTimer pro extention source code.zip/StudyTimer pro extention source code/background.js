/**
 * StudyTimer Pro - Chrome Extension
 * Copyright (c) 2025 Rohit K.S. (rohitks.com.np)
 * All rights reserved.
 * 
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 */

chrome.runtime.onInstalled.addListener(async (details) => {
  // Only show install notification on actual first install, not updates or browser restarts
  if (details.reason !== 'install') {
    return;
  }
  
  const defaultData = {
    subjects: [],
    bookmarks: [],
    todayStudyTime: 0,
    totalStudyTime: 0,
    currentStreak: 0,
    longestStreak: 0,
    lastStudyDate: null,
    sessionActive: false,
    sessionStart: null,
    totalSessions: 0,
    weekStudyTime: 0,
    achievements: [
      { id: 'first_session', name: 'First Step', desc: 'Complete first study session', icon: '🎯', unlocked: false },
      { id: 'streak_3', name: '3 Day Streak', desc: 'Study for 3 days straight', icon: '🔥', unlocked: false },
      { id: 'streak_7', name: 'Week Warrior', desc: '7 day study streak', icon: '⭐', unlocked: false },
      { id: 'hours_10', name: 'Dedicated', desc: 'Study for 10 total hours', icon: '📚', unlocked: false },
      { id: 'hours_50', name: 'Expert', desc: 'Study for 50 total hours', icon: '🏆', unlocked: false },
      { id: 'subject_5', name: 'Multi-tasker', desc: 'Add 5 subjects', icon: '📖', unlocked: false }
    ],
    plannerNotes: []
  };

  const defaultSettings = {
    theme: 'light',
    dailyGoal: 60,
    dailyResetEnabled: true,
    reminders: true,
    achievements: true,
    streakReminders: true,
    extensionName: 'StudyTimer Pro',
    extensionSubtitle: 'Track Your Study Progress',
    siteName: 'Study Site',
    siteUrl: 'https://read.rohitks.com.np',
    headerIcon: '📚',
    floatingTimer: true,
    floatingTimerPosition: 'left',
    timerStopNotification: true,
    milestoneNotifications: true
  };

  const result = await chrome.storage.local.get(['studyData', 'settings']);
  if (!result.studyData) {
    await chrome.storage.local.set({ studyData: defaultData });
  }
  if (!result.settings) {
    await chrome.storage.local.set({ settings: defaultSettings });
  }

  chrome.notifications.create('install-notification', {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'StudyTimer Pro',
    message: 'Study tracker installed! Click the icon to start your learning journey.'
  });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'studyReminder') {
    chrome.notifications.create('study-reminder-' + Date.now(), {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Study Reminder',
      message: 'Time for your study session! Keep up the great work.',
      priority: 2
    }, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Study reminder notification error:', chrome.runtime.lastError);
      }
    });
  } else if (alarm.name === 'dailyReset') {
    await performDailyReset();
  }
});

// Schedule initial daily reset alarm
scheduleResetAlarm();

async function scheduleResetAlarm() {
  const result = await chrome.storage.local.get(['settings']);
  const settings = result.settings || {};
  
  await chrome.alarms.clear('dailyReset');
  
  // Only schedule if daily reset is enabled
  if (settings.dailyResetEnabled !== false) {
    const nextReset = getNextMidnight();
    
    chrome.alarms.create('dailyReset', {
      when: nextReset,
      periodInMinutes: 24 * 60
    });
    
    console.log('Daily reset scheduled for:', new Date(nextReset).toString());
  }
}

function getNextMidnight() {
  // Get current time in user's local timezone
  const now = new Date();
  
  // Create midnight for tomorrow in user's local timezone
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0); // Midnight (12:00 AM)
  
  return tomorrow.getTime();
}

function getTodayDateString() {
  // Get today's date in user's local timezone as YYYY-MM-DD
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Check if we missed any daily resets while browser was closed
async function checkMissedReset() {
  const result = await chrome.storage.local.get(['lastResetDate', 'settings', 'studyData']);
  const settings = result.settings || {};
  const lastResetDate = result.lastResetDate;
  const todayStr = getTodayDateString();
  
  // If daily reset is disabled, skip
  if (settings.dailyResetEnabled === false) {
    return;
  }
  
  // If no last reset date recorded, this is first run - just record today
  if (!lastResetDate) {
    await chrome.storage.local.set({ lastResetDate: todayStr });
    console.log('First run - set lastResetDate to:', todayStr);
    return;
  }
  
  // If last reset was before today, we missed a reset
  if (lastResetDate < todayStr) {
    console.log('Missed reset detected! Last reset:', lastResetDate, 'Today:', todayStr);
    await performDailyReset();
  }
}

// Track last reset date to prevent multiple resets on same day
let lastResetDate = null;

async function performDailyReset() {
  const todayStr = getTodayDateString();
  
  // Prevent multiple resets on the same calendar day
  // Also check storage for persistence across browser restarts
  const stored = await chrome.storage.local.get(['lastResetDate']);
  if (stored.lastResetDate === todayStr || lastResetDate === todayStr) {
    console.log('Daily reset already performed today:', todayStr);
    return;
  }
  
  // Mark this day as reset (both in memory and storage)
  lastResetDate = todayStr;
  await chrome.storage.local.set({ lastResetDate: todayStr });
  
  const result = await chrome.storage.local.get(['studyData', 'settings']);
  const studyData = result.studyData;
  const settings = result.settings || {};
  
  if (studyData) {
    // If session is active, calculate final time before reset
    let finalTodayTime = studyData.todayStudyTime;
    if (studyData.sessionActive && studyData.sessionStart) {
      const elapsed = Math.floor((Date.now() - studyData.sessionStart) / 1000);
      finalTodayTime = (studyData.sessionBaseTime || 0) + elapsed;
    }
    
    // Save today's study time to history before resetting
    if (finalTodayTime > 0 || studyData.lastStudyDate) {
      if (!studyData.studyHistory) {
        studyData.studyHistory = [];
      }
      
      // Get yesterday's date in user's local timezone (the day we're archiving)
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const dateStr = yesterday.toISOString().split('T')[0];
      
      // Check if we already have an entry for this date
      const existingIndex = studyData.studyHistory.findIndex(h => h.date === dateStr);
      
      if (existingIndex === -1 && finalTodayTime > 0) {
        studyData.studyHistory.push({
          date: dateStr,
          studyTime: finalTodayTime,
          sessions: studyData.totalSessions
        });
        
        // Keep only last 90 days of history
        if (studyData.studyHistory.length > 90) {
          studyData.studyHistory = studyData.studyHistory.slice(-90);
        }
      } else if (existingIndex !== -1) {
        // Update existing entry with final time
        studyData.studyHistory[existingIndex].studyTime = finalTodayTime;
      }
    }
    
    // Format yesterday's study time for notification
    const hours = Math.floor(finalTodayTime / 3600);
    const minutes = Math.floor((finalTodayTime % 3600) / 60);
    let timeMessage = '';
    if (hours > 0) {
      timeMessage = `${hours}h ${minutes}m`;
    } else if (minutes > 0) {
      timeMessage = `${minutes} minutes`;
    } else {
      timeMessage = 'less than a minute';
    }
    
    // Reset daily time
    studyData.todayStudyTime = 0;
    
    // If session was active, reset the base time so timer continues from 0
    const wasSessionActive = studyData.sessionActive;
    if (wasSessionActive) {
      studyData.sessionBaseTime = 0;
      studyData.sessionStart = Date.now(); // Reset session start to now
    }
    
    await chrome.storage.local.set({ studyData });
    
    // Also update the global sessionActive flag if needed
    await chrome.storage.local.set({ sessionActive: wasSessionActive });
    
    // Send notification about daily reset
    const notificationMessage = wasSessionActive 
      ? `Previous day: ${timeMessage} studied. Timer reset to 00:00:00 - session continues!`
      : `Previous day: ${timeMessage} studied. Ready for a new day!`;
    
    chrome.notifications.create('daily-reset', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '🌅 New Day - Timer Reset',
      message: notificationMessage,
      priority: 2
    }, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Daily reset notification error:', chrome.runtime.lastError);
      }
    });
    
    // Notify all tabs about the reset with time = 0
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'TIMER_UPDATE',
          time: 0,
          resetOccurred: true,
          sessionActive: wasSessionActive
        }).catch(() => {});
      });
    });
    
    // Re-schedule alarm for next day
    scheduleResetAlarm();
  }
}

chrome.notifications.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'https://read.rohitks.com.np' });
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    const result = await chrome.storage.local.get(['sessionActive', 'settings', 'studyData']);

    if (result.sessionActive && result.settings?.floatingTimer) {
      chrome.tabs.sendMessage(tabId, {
        type: 'TIMER_START',
        settings: {
          enabled: result.settings.floatingTimer,
          position: result.settings.floatingTimerPosition || 'left'
        },
        time: result.studyData?.todayStudyTime || 0
      }).catch(() => {});
    }
  }
});

let timerInterval = null;

function startBackgroundTimer() {
  if (timerInterval) return;

  timerInterval = setInterval(async () => {
    const result = await chrome.storage.local.get(['studyData', 'settings']);
    const studyData = result.studyData;
    const settings = result.settings || {};

    if (studyData && studyData.sessionActive) {
      const elapsed = Math.floor((Date.now() - studyData.sessionStart) / 1000);
      const previousTime = studyData.todayStudyTime;
      studyData.todayStudyTime = (studyData.sessionBaseTime || 0) + elapsed;

      if (settings.milestoneNotifications !== false) {
        const previousHours = Math.floor(previousTime / 3600);
        const currentHours = Math.floor(studyData.todayStudyTime / 3600);

        if (currentHours > previousHours && currentHours <= 3) {
          chrome.notifications.create('milestone-' + currentHours + '-' + Date.now(), {
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: 'Study Milestone!',
            message: `Great job! You've studied for ${currentHours} hour${currentHours > 1 ? 's' : ''} today!`
          }, (notificationId) => {
            if (chrome.runtime.lastError) {
              console.error('Milestone notification error:', chrome.runtime.lastError);
            }
          });
        }
      }

      await chrome.storage.local.set({ studyData });

      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'TIMER_UPDATE',
            time: studyData.todayStudyTime
          }).catch(() => {});
        });
      });
    }
  }, 1000);
}

function stopBackgroundTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

chrome.runtime.onStartup.addListener(async () => {
  console.log('Browser started - checking for missed resets...');
  
  // First check if we missed any daily resets while browser was closed
  await checkMissedReset();
  
  // Reschedule the daily reset alarm
  await scheduleResetAlarm();
  
  // Then restart timer if session was active
  const result = await chrome.storage.local.get(['studyData']);
  if (result.studyData?.sessionActive) {
    startBackgroundTimer();
  }
});

// Also check on service worker wake-up (handles extension restart)
(async () => {
  console.log('Service worker started - checking for missed resets...');
  
  // Check for missed resets
  await checkMissedReset();
  
  // Restart timer if session was active
  const result = await chrome.storage.local.get(['studyData']);
  if (result && result.studyData?.sessionActive) {
    startBackgroundTimer();
  }
})();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_TIMER_STATE') {
    chrome.storage.local.get(['sessionActive', 'settings', 'studyData'], (result) => {
      const data = result || {};
      sendResponse({
        sessionActive: data.sessionActive,
        settings: data.settings,
        time: data.studyData?.todayStudyTime || 0
      });
    });
    return true;
  }

  if (message.type === 'START_SESSION') {
    chrome.storage.local.get(['studyData'], async (result) => {
      const studyData = result.studyData;
      studyData.sessionActive = true;
      studyData.sessionStart = Date.now();
      studyData.sessionBaseTime = studyData.todayStudyTime;
      studyData.totalSessions++;
      await chrome.storage.local.set({ studyData });
      startBackgroundTimer();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'STOP_SESSION') {
    chrome.storage.local.get(['studyData', 'settings'], async (result) => {
      const studyData = result.studyData;
      const settings = result.settings || {};
      const sessionDuration = studyData.todayStudyTime - (studyData.sessionBaseTime || 0);

      studyData.sessionActive = false;
      studyData.totalStudyTime += sessionDuration;
      studyData.weekStudyTime += sessionDuration;
      
      // Update today's session count in history for live tracking (user's local timezone)
      const todayStr = getTodayDateString();
      
      if (!studyData.studyHistory) {
        studyData.studyHistory = [];
      }
      
      // Find or create today's entry
      let todayEntry = studyData.studyHistory.find(h => h.date === todayStr);
      if (!todayEntry) {
        todayEntry = { date: todayStr, studyTime: 0, sessions: 0 };
        studyData.studyHistory.push(todayEntry);
      }
      todayEntry.studyTime = studyData.todayStudyTime;
      todayEntry.sessions++;
      
      await chrome.storage.local.set({ studyData });
      stopBackgroundTimer();

      if (settings.timerStopNotification !== false && sessionDuration > 0) {
        const hours = Math.floor(sessionDuration / 3600);
        const minutes = Math.floor((sessionDuration % 3600) / 60);
        const seconds = sessionDuration % 60;

        let timeMessage = '';
        if (hours > 0) {
          timeMessage = `${hours} hour${hours > 1 ? 's' : ''}`;
          if (minutes > 0) timeMessage += ` ${minutes} minute${minutes > 1 ? 's' : ''}`;
        } else if (minutes > 0) {
          timeMessage = `${minutes} minute${minutes > 1 ? 's' : ''}`;
          if (seconds > 0) timeMessage += ` ${seconds} second${seconds > 1 ? 's' : ''}`;
        } else {
          timeMessage = `${seconds} second${seconds > 1 ? 's' : ''}`;
        }

        chrome.notifications.create('session-ended-' + Date.now(), {
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: 'Study Session Ended',
          message: `Great work! You studied for ${timeMessage} in this session.`
        }, (notificationId) => {
          if (chrome.runtime.lastError) {
            console.error('Timer stop notification error:', chrome.runtime.lastError);
          }
        });
      }

      sendResponse({ success: true, studyData });
    });
    return true;
  }
  
  if (message.type === 'UPDATE_RESET_TIME') {
    scheduleResetAlarm();
    sendResponse({ success: true });
    return true;
  }
});
