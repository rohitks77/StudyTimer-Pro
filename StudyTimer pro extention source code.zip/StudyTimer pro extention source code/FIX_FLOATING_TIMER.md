# Fix Floating Timer - Complete Reinstall Guide

The floating timer only shows in the popup because the extension needs to be **completely removed and reinstalled** to get the new permissions.

## Why This Happens

Chrome doesn't always ask for new permissions when you just reload an extension during development. You need to remove it completely and load it fresh.

## Step-by-Step Fix

### 1. Remove the Extension Completely

1. Open Chrome and go to: `chrome://extensions/`
2. Find "RohitKS Study Assistant"
3. Click the **REMOVE** button (not reload)
4. Confirm removal

### 2. Reinstall the Extension

1. Still on `chrome://extensions/`
2. Make sure **Developer mode** is ON (toggle in top-right)
3. Click **Load unpacked**
4. Select your project folder (the folder containing `manifest.json`)
5. Chrome will show a permission popup saying: **"Read and change all your data on all websites"**
6. Click **Add Extension** or **Allow**

### 3. Close All Open Tabs

**IMPORTANT**: The content script only loads when a page loads. So you need to:
1. Close ALL your Chrome tabs
2. Open a brand new tab (go to any website like google.com or youtube.com)

### 4. Test the Timer

1. Click the extension icon in Chrome toolbar
2. Click the Settings gear icon (⚙️)
3. Make sure **"Show Floating Timer"** toggle is ON (blue/enabled)
4. Go back to the main popup screen
5. Click **"Start Session"**

### 5. Expected Result

You should now see the floating timer at the bottom-left corner of **every browser tab**:

```
┌─────────────────────┐
│ 🕐  00:00:00       │
└─────────────────────┘
```

The timer should:
- ✅ Appear on all tabs (Google, YouTube, any website)
- ✅ Update every second
- ✅ Stay visible when you switch tabs
- ✅ Persist across different websites
- ✅ NOT appear in the popup (only on regular web pages)

## Still Not Working?

### Debug Step 1: Check Content Script

1. Go to any website (like google.com)
2. Press **F12** to open DevTools
3. Click the **Console** tab
4. You should see these messages:
   ```
   RohitKS Study Assistant: Content script loaded
   Initializing timer with state: {sessionActive: true, settings: {...}}
   ```

If you **DON'T see** these messages:
- The content script is not loading
- Try reinstalling the extension again following steps above

### Debug Step 2: Check Permissions

1. Go to: `chrome://extensions/`
2. Find "RohitKS Study Assistant"
3. Click **Details**
4. Under "Permissions" section, you should see:
   - ✅ Read and change all your data on all websites
   - ✅ Display notifications
   - ✅ Manage your apps, extensions, and themes

If you **DON'T see** "Read and change all your data on all websites":
- The extension doesn't have permission to inject content scripts
- Remove and reinstall following steps above

### Debug Step 3: Check if Timer Element Exists

1. Go to any website with DevTools open (F12)
2. Click the **Elements** tab
3. Press `Ctrl+F` (or `Cmd+F` on Mac)
4. Search for: `study-floating-timer`

If element is found:
- Check if it has the class `active`
- If no `active` class, the timer is hidden due to settings
- Go to extension settings and toggle "Show Floating Timer" off and on again

If element is NOT found:
- Content script is not running
- Remove and reinstall the extension

## Quick Checklist

Before asking for more help, verify:

- [ ] Extension was completely REMOVED (not just reloaded)
- [ ] Extension was reinstalled using "Load unpacked"
- [ ] Permission popup appeared and you clicked "Allow"
- [ ] ALL browser tabs were closed and reopened
- [ ] "Show Floating Timer" is ON in settings
- [ ] Session was started by clicking "Start Session"
- [ ] Console shows "Content script loaded" message
- [ ] Permissions page shows "Read and change all your data"

If ALL checkboxes are checked and it still doesn't work, there may be another issue.
