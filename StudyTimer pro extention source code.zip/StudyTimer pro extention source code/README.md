# StudyTimer Pro

Study time tracker with achievements, streaks, and progress tracking

## Features

- ⏱ Study timer with session tracking
- 📚 Subject management system
- 🔥 Daily streaks and achievements
- 📊 Progress and statistics tracking
- 🔖 Bookmarks for study materials
- 🌐 Quick access to read.rohitks.com.np

## Installation

1. **Create Icons** - Open `icons/create-icons-now.html` in browser, download 3 PNG files, move to icons/ folder
2. **Load Extension** - Open chrome://extensions/, enable Developer mode, click Load unpacked, select project folder
3. **Start Studying** - Click extension icon, add subjects, start session!

## Quick Start

1. Click extension icon
2. Click "Start Session" to begin tracking time
3. Add subjects with "+ Add Subject"
4. View progress in different tabs
5. Earn achievements as you study!

## Data Storage

All data stored locally using Chrome storage. No external servers. Complete privacy.

## License

MIT License
