/**
 * StudyTimer Pro - Chrome Extension
 * Copyright (c) 2025 Rohit K.S. (rohitks.com.np)
 * All rights reserved.
 * 
 * This code is proprietary and confidential.
 * Unauthorized copying, modification, or distribution is strictly prohibited.
 */

let studyData = {};
let settings = {};
let sessionActive = false;
let sessionStart = null;
let editingSubjectId = null;

async function loadData() {
  const result = await chrome.storage.local.get(['studyData', 'settings']);
  studyData = result.studyData || getDefaultData();
  settings = result.settings || getDefaultSettings();

  applyTheme(settings.theme);
  applyBranding();
  updateAllUI();
  updateSettingsUI();

  if (studyData.sessionActive) {
    sessionActive = true;
    sessionStart = studyData.sessionStart;
    updateSessionButton(true);
  }
}

function getDefaultSettings() {
  return {
    theme: 'light',
    dailyGoal: 60,
    dailyResetEnabled: true,
    reminders: true,
    achievements: true,
    streakReminders: true,
    extensionName: 'StudyTimer Pro',
    extensionSubtitle: 'Track Your Study Progress',
    siteName: 'Study Site',
    siteUrl: 'https://read.rohitks.com.np',
    headerIcon: '📚',
    floatingTimer: true,
    floatingTimerPosition: 'left',
    timerStopNotification: true,
    milestoneNotifications: true
  };
}

function getDefaultData() {
  return {
    subjects: [],
    bookmarks: [],
    todayStudyTime: 0,
    totalStudyTime: 0,
    currentStreak: 0,
    longestStreak: 0,
    lastStudyDate: null,
    sessionActive: false,
    sessionStart: null,
    totalSessions: 0,
    weekStudyTime: 0,
    achievements: generateAchievements(),
    notes: {},
    studyHistory: [],
    plannerNotes: []
  };
}

function generateAchievements() {
  return [
    { id: 'first_session', name: 'First Step', desc: 'Complete first study session', icon: '🎯', unlocked: false },
    { id: 'streak_3', name: '3 Day Streak', desc: 'Study for 3 days straight', icon: '🔥', unlocked: false },
    { id: 'streak_7', name: 'Week Warrior', desc: '7 day study streak', icon: '⭐', unlocked: false },
    { id: 'hours_10', name: 'Dedicated', desc: 'Study for 10 total hours', icon: '📚', unlocked: false },
    { id: 'hours_50', name: 'Expert', desc: 'Study for 50 total hours', icon: '🏆', unlocked: false },
    { id: 'subject_5', name: 'Multi-tasker', desc: 'Add 5 subjects', icon: '📖', unlocked: false }
  ];
}

function updateAllUI() {
  updateTimer();
  updateStreak();
  updateSubjects();
  updateProgress();
  updateStats();
  updateStudyHistory();
  updateAchievements();
}

function updateTimer() {
  const hours = Math.floor(studyData.todayStudyTime / 3600);
  const minutes = Math.floor((studyData.todayStudyTime % 3600) / 60);
  const seconds = studyData.todayStudyTime % 60;
  const timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  document.getElementById('timerDisplay').textContent = timeString;

  const floatingTimerDisplay = document.getElementById('floatingTimerDisplay');
  if (floatingTimerDisplay) {
    floatingTimerDisplay.textContent = timeString;
  }
}

function updateStreak() {
  document.getElementById('streakDays').textContent = studyData.currentStreak;

  const today = new Date().toDateString();
  if (studyData.lastStudyDate !== today && studyData.todayStudyTime > 0) {
    const yesterday = new Date(Date.now() - 86400000).toDateString();
    if (studyData.lastStudyDate === yesterday) {
      studyData.currentStreak++;
    } else if (studyData.lastStudyDate !== today) {
      studyData.currentStreak = 1;
    }
    studyData.lastStudyDate = today;
    if (studyData.currentStreak > studyData.longestStreak) {
      studyData.longestStreak = studyData.currentStreak;
    }
    saveData();
  }
}

function updateSubjects() {
  const list = document.getElementById('subjectsList');
  if (studyData.subjects.length === 0) {
    list.innerHTML = '<div class="empty-state">No subjects added yet. Click "+ Add Subject" to start.</div>';
    return;
  }

  list.innerHTML = studyData.subjects.map(subject => {
    const progress = subject.completed ? 100 : (subject.progress || 0);
    const hasNotes = studyData.notes && studyData.notes[subject.id] && studyData.notes[subject.id].length > 0;
    const isBookmarked = studyData.bookmarks.some(b => b.title === subject.name);

    return `
      <div class="subject-card" data-subject-id="${subject.id}">
        <div class="subject-header">
          <div class="subject-info">
            <h3>${subject.name}</h3>
          </div>
        </div>
        <div class="subject-meta">
          <span>${progress}% complete</span>
          ${hasNotes ? '<span>📝 Has notes</span>' : ''}
          ${isBookmarked ? '<span>🔖 Bookmarked</span>' : ''}
        </div>
        <div class="progress-bar-container">
          <div class="progress-bar" style="width: ${progress}%"></div>
        </div>
        <div class="subject-actions">
          <button class="action-btn" data-action="decrease" data-id="${subject.id}" title="Decrease progress">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
          <button class="action-btn" data-action="increase" data-id="${subject.id}" title="Increase progress">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
          <button class="action-btn ${hasNotes ? 'primary' : ''}" data-action="notes" data-id="${subject.id}" title="Open notes">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
          <button class="action-btn" data-action="open" data-id="${subject.id}" title="Open study site">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
          </button>
          <button class="action-btn ${isBookmarked ? 'primary' : ''}" data-action="bookmark" data-id="${subject.id}" title="${isBookmarked ? 'Already bookmarked' : 'Bookmark subject'}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="${isBookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
            </svg>
          </button>
          <button class="action-btn" data-action="edit" data-id="${subject.id}" title="Edit subject name">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
            </svg>
          </button>
          <button class="action-btn danger" data-action="delete" data-id="${subject.id}" title="Delete subject">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      </div>
    `;
  }).join('');

  attachSubjectEventListeners();
}

function attachSubjectEventListeners() {
  document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const action = btn.dataset.action;
      const id = btn.dataset.id;

      switch(action) {
        case 'increase':
          adjustProgress(id, 10);
          break;
        case 'decrease':
          adjustProgress(id, -10);
          break;
        case 'notes':
          openNotes(id);
          break;
        case 'open':
          openSubject(id);
          break;
        case 'bookmark':
          bookmarkSubject(id);
          break;
        case 'edit':
          editSubject(id);
          break;
        case 'delete':
          deleteSubject(id);
          break;
      }
    });
  });
}

function adjustProgress(id, amount) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    subject.progress = Math.max(0, Math.min(100, (subject.progress || 0) + amount));
    subject.completed = subject.progress === 100;
    saveData();
    updateSubjects();
  }
}

let currentNotesSubjectId = null;

function openNotes(id) {
  currentNotesSubjectId = id;
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    if (!studyData.notes) studyData.notes = {};
    const modal = document.getElementById('notesModal');
    document.getElementById('notesModalTitle').textContent = `Notes: ${subject.name}`;
    document.getElementById('notesTextarea').value = studyData.notes[id] || '';
    modal.classList.add('active');
  }
}

function saveNotes() {
  if (currentNotesSubjectId) {
    const notesText = document.getElementById('notesTextarea').value;
    if (!studyData.notes) studyData.notes = {};
    studyData.notes[currentNotesSubjectId] = notesText;
    saveData();
    updateSubjects();
    closeNotesModal();
  }
}

function closeNotesModal() {
  document.getElementById('notesModal').classList.remove('active');
  currentNotesSubjectId = null;
}

function increaseProgress(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    subject.progress = Math.min(100, (subject.progress || 0) + 10);
    subject.completed = subject.progress === 100;
    saveData();
    updateSubjects();
  }
}

function decreaseProgress(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    subject.progress = Math.max(0, (subject.progress || 0) - 10);
    if (subject.progress < 100) subject.completed = false;
    saveData();
    updateSubjects();
  }
}

function updateProgress() {
  const totalMinutes = Math.floor(studyData.totalStudyTime / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  document.getElementById('totalStudyTime').textContent = `${hours}h ${minutes}m`;

  const completed = studyData.subjects.filter(s => s.completed).length;
  document.getElementById('completedSubjects').textContent = `${completed}/${studyData.subjects.length}`;

  const avgProgress = studyData.subjects.length > 0
    ? Math.round(studyData.subjects.reduce((sum, s) => sum + s.progress, 0) / studyData.subjects.length)
    : 0;
  document.getElementById('avgProgress').textContent = avgProgress + '%';
}

function updateStats() {
  const todayMinutes = Math.floor(studyData.todayStudyTime / 60);
  document.getElementById('todayMinutes').textContent = todayMinutes;

  const weekMinutes = Math.floor(studyData.weekStudyTime / 60);
  document.getElementById('weekMinutes').textContent = weekMinutes;

  document.getElementById('totalSessions').textContent = studyData.totalSessions;
  document.getElementById('longestStreak').textContent = studyData.longestStreak;
}

function updateStudyHistory() {
  const list = document.getElementById('studyHistoryList');
  if (!list) return;
  
  if (!studyData.studyHistory) {
    studyData.studyHistory = [];
  }
  
  if (studyData.studyHistory.length === 0) {
    list.innerHTML = '<div class="empty-state">No study history yet. Complete study sessions to track your progress!</div>';
    return;
  }
  
  // Show last 14 days, most recent first
  const recentHistory = [...studyData.studyHistory].reverse().slice(0, 14);
  
  list.innerHTML = recentHistory.map(entry => {
    const date = new Date(entry.date);
    const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
    const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const hours = Math.floor(entry.studyTime / 3600);
    const minutes = Math.floor((entry.studyTime % 3600) / 60);
    const timeStr = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
    const sessions = entry.sessions || 0;
    
    // Calculate percentage of daily goal
    const goalMinutes = settings.dailyGoal || 60;
    const studiedMinutes = Math.floor(entry.studyTime / 60);
    const percentage = Math.min(100, Math.round((studiedMinutes / goalMinutes) * 100));
    
    return `
      <div class="history-item">
        <div class="history-date">
          <span class="history-day">${dayName}</span>
          <span class="history-date-text">${dateStr}</span>
        </div>
        <div class="history-stats">
          <div class="history-time">${timeStr}</div>
          <div class="history-sessions">${sessions} session${sessions !== 1 ? 's' : ''}</div>
        </div>
        <div class="history-progress">
          <div class="history-progress-bar" style="width: ${percentage}%"></div>
        </div>
        <div class="history-percentage">${percentage}%</div>
      </div>
    `;
  }).join('');
}

function updateBookmarks() {
  const list = document.getElementById('bookmarksList');

  if (!studyData.bookmarks || studyData.bookmarks.length === 0) {
    list.innerHTML = '<div class="empty-state">No bookmarks yet</div>';
    return;
  }

  list.innerHTML = studyData.bookmarks.map(bookmark => `
    <div class="bookmark-item">
      <div class="bookmark-info">
        <div class="bookmark-title">${bookmark.title}</div>
        <div class="bookmark-url">${bookmark.url}</div>
      </div>
      <div class="bookmark-actions">
        <button class="bookmark-open-btn" data-url="${bookmark.url}" title="Open bookmark">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
            <polyline points="15 3 21 3 21 9"></polyline>
            <line x1="10" y1="14" x2="21" y2="3"></line>
          </svg>
        </button>
        <button class="bookmark-delete-btn" data-id="${bookmark.id}" title="Delete bookmark">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    </div>
  `).join('');

  attachBookmarkEventListeners();
}

function attachBookmarkEventListeners() {
  document.querySelectorAll('.bookmark-open-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.dataset.url;
      chrome.tabs.create({ url });
    });
  });

  document.querySelectorAll('.bookmark-delete-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      studyData.bookmarks = studyData.bookmarks.filter(b => b.id !== id);
      saveData();
      updateSubjects();
      updateBookmarks();
    });
  });
}

function updateAchievements() {
  const list = document.getElementById('achievementsList');
  if (!studyData.achievements) {
    studyData.achievements = generateAchievements();
  }

  checkAchievements();

  list.innerHTML = studyData.achievements.map(ach => `
    <div class="achievement-card ${ach.unlocked ? 'unlocked' : ''}">
      <div class="achievement-icon">${ach.unlocked ? ach.icon : '🔒'}</div>
      <div class="achievement-name">${ach.name}</div>
      <div class="achievement-desc">${ach.desc}</div>
    </div>
  `).join('');
}

function checkAchievements() {
  const totalHours = studyData.totalStudyTime / 3600;

  if (studyData.totalSessions >= 1 && !studyData.achievements.find(a => a.id === 'first_session').unlocked) {
    unlockAchievement('first_session');
  }
  if (studyData.currentStreak >= 3 && !studyData.achievements.find(a => a.id === 'streak_3').unlocked) {
    unlockAchievement('streak_3');
  }
  if (studyData.currentStreak >= 7 && !studyData.achievements.find(a => a.id === 'streak_7').unlocked) {
    unlockAchievement('streak_7');
  }
  if (totalHours >= 10 && !studyData.achievements.find(a => a.id === 'hours_10').unlocked) {
    unlockAchievement('hours_10');
  }
  if (totalHours >= 50 && !studyData.achievements.find(a => a.id === 'hours_50').unlocked) {
    unlockAchievement('hours_50');
  }
  if (studyData.subjects.length >= 5 && !studyData.achievements.find(a => a.id === 'subject_5').unlocked) {
    unlockAchievement('subject_5');
  }
}

function unlockAchievement(id) {
  const ach = studyData.achievements.find(a => a.id === id);
  if (ach && !ach.unlocked) {
    ach.unlocked = true;
    saveData(); // Save immediately to prevent duplicate notifications
    chrome.notifications.create('achievement-' + id, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Achievement Unlocked!',
      message: `${ach.icon} ${ach.name}: ${ach.desc}`
    }, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Achievement notification error:', chrome.runtime.lastError);
      }
    });
  }
}

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.studyData) {
    const newData = changes.studyData.newValue;
    if (newData) {
      studyData.todayStudyTime = newData.todayStudyTime;
      studyData.sessionActive = newData.sessionActive;
      updateTimer();
    }
  }
});

function updateSessionButton(active) {
  const btn = document.getElementById('startSessionBtn');
  if (active) {
    btn.innerHTML = `
      <svg class="session-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="6" y="4" width="4" height="16"></rect>
        <rect x="14" y="4" width="4" height="16"></rect>
      </svg>
      <span class="session-text">Stop Session</span>
    `;
    btn.classList.add('active');
  } else {
    btn.innerHTML = `
      <svg class="session-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <polygon points="10 8 16 12 10 16 10 8"></polygon>
      </svg>
      <span class="session-text">Start Session</span>
    `;
    btn.classList.remove('active');
  }

  updateFloatingTimer(active);
}

function updateFloatingTimer(active) {
  const floatingTimer = document.getElementById('floatingTimer');

  if (floatingTimer) {
    if (active && settings.floatingTimer) {
      floatingTimer.classList.add('active');
    } else {
      floatingTimer.classList.remove('active');
    }

    floatingTimer.classList.remove('left', 'right');
    floatingTimer.classList.add(settings.floatingTimerPosition || 'left');
  }

  broadcastFloatingTimerState(active);
}

function broadcastFloatingTimerState(active) {
  chrome.tabs.query({}, (tabs) => {
    const message = active ? {
      type: 'TIMER_START',
      settings: {
        enabled: settings.floatingTimer,
        position: settings.floatingTimerPosition || 'left'
      },
      time: studyData.todayStudyTime
    } : {
      type: 'TIMER_STOP'
    };

    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    });
  });
}

function saveData() {
  chrome.storage.local.set({ studyData });
}

function toggleComplete(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    subject.completed = !subject.completed;
    subject.progress = subject.completed ? 100 : Math.max(0, subject.progress - 10);
    saveData();
    updateSubjects();
    updateProgress();
  }
}

function increaseProgress(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject && !subject.completed) {
    subject.progress = Math.min(100, (subject.progress || 0) + 10);
    if (subject.progress === 100) {
      subject.completed = true;
    }
    saveData();
    updateSubjects();
    updateProgress();
  }
}

function decreaseProgress(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    subject.progress = Math.max(0, (subject.progress || 0) - 10);
    if (subject.progress < 100) {
      subject.completed = false;
    }
    saveData();
    updateSubjects();
    updateProgress();
  }
}

function bookmarkSubject(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    const existingBookmark = studyData.bookmarks.find(b => b.title === subject.name);
    if (existingBookmark) {
      chrome.notifications.create('already-bookmarked-' + Date.now(), {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Already Bookmarked',
        message: `${subject.name} is already in your bookmarks`
      }, (notificationId) => {
        if (chrome.runtime.lastError) {
          console.error('Notification error:', chrome.runtime.lastError);
        }
      });
      return;
    }

    studyData.bookmarks.push({
      id: Date.now().toString(),
      title: subject.name,
      url: settings.siteUrl || 'https://read.rohitks.com.np',
      date: new Date().toISOString()
    });
    saveData();
    updateSubjects();
    updateBookmarks();
    chrome.notifications.create('bookmarked-' + Date.now(), {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Bookmarked',
      message: `${subject.name} has been bookmarked`
    }, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.error('Notification error:', chrome.runtime.lastError);
      }
    });
  }
}

function openSubject(id) {
  chrome.tabs.create({ url: settings.siteUrl || 'https://read.rohitks.com.np' });
}

function editSubject(id) {
  const subject = studyData.subjects.find(s => s.id === id);
  if (subject) {
    editingSubjectId = id;
    document.getElementById('modalTitle').textContent = 'Edit Subject';
    document.getElementById('subjectNameInput').value = subject.name;
    document.getElementById('subjectModal').classList.add('active');
  }
}

function deleteSubject(id) {
  if (confirm('Are you sure you want to delete this subject?')) {
    studyData.subjects = studyData.subjects.filter(s => s.id !== id);
    saveData();
    updateSubjects();
    updateProgress();
  }
}

function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'dark') {
    root.setAttribute('data-theme', 'dark');
    document.getElementById('themeToggle').textContent = '☀️';
  } else if (theme === 'light') {
    root.setAttribute('data-theme', 'light');
    document.getElementById('themeToggle').textContent = '🌙';
  } else {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    root.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    document.getElementById('themeToggle').textContent = '🔄';
  }
}

function updateSettingsUI() {
  document.getElementById('dailyGoalInput').value = settings.dailyGoal || 60;
  document.getElementById('dailyResetToggle').checked = settings.dailyResetEnabled !== false;
  document.getElementById('resetTimeContainer').style.display = settings.dailyResetEnabled !== false ? 'flex' : 'none';
  document.getElementById('remindersToggle').checked = settings.reminders !== false;
  document.getElementById('achievementsToggle').checked = settings.achievements !== false;
  document.getElementById('streakToggle').checked = settings.streakReminders !== false;
  document.getElementById('floatingTimerToggle').checked = settings.floatingTimer !== false;
  document.getElementById('timerStopToggle').checked = settings.timerStopNotification !== false;
  document.getElementById('milestoneToggle').checked = settings.milestoneNotifications !== false;

  document.getElementById('extensionNameInput').value = settings.extensionName || 'StudyTimer Pro';
  document.getElementById('extensionSubtitleInput').value = settings.extensionSubtitle || 'Track Your Study Progress';
  document.getElementById('siteNameInput').value = settings.siteName || 'Study Site';
  document.getElementById('siteUrlInput').value = settings.siteUrl || 'https://read.rohitks.com.np';

  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === settings.theme);
  });

  document.querySelectorAll('.theme-btn[data-position]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.position === (settings.floatingTimerPosition || 'left'));
  });
}

function applyBranding() {
  document.getElementById('headerTitle').textContent = settings.extensionName || 'StudyTimer Pro';
  document.getElementById('headerSubtitle').textContent = settings.extensionSubtitle || 'Track Your Study Progress';

  const openSiteBtn = document.getElementById('openSiteBtn');
  const siteName = settings.siteName || 'Study Site';
  openSiteBtn.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
      <polyline points="15 3 21 3 21 9"></polyline>
      <line x1="10" y1="14" x2="21" y2="3"></line>
    </svg>
    <span>Open ${siteName}</span>
  `;
}

function saveSettings() {
  chrome.storage.local.set({ settings });
}

document.getElementById('themeToggle').addEventListener('click', () => {
  const themes = ['light', 'dark', 'auto'];
  const currentIndex = themes.indexOf(settings.theme);
  settings.theme = themes[(currentIndex + 1) % themes.length];
  applyTheme(settings.theme);
  updateSettingsUI();
  saveSettings();
});

document.querySelectorAll('.theme-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    settings.theme = btn.dataset.theme;
    applyTheme(settings.theme);
    updateSettingsUI();
    saveSettings();
  });
});

document.getElementById('dailyGoalInput').addEventListener('change', (e) => {
  settings.dailyGoal = parseInt(e.target.value) || 60;
  saveSettings();
});

document.getElementById('dailyResetToggle').addEventListener('change', (e) => {
  settings.dailyResetEnabled = e.target.checked;
  document.getElementById('resetTimeContainer').style.display = e.target.checked ? 'flex' : 'none';
  saveSettings();
  chrome.runtime.sendMessage({ type: 'UPDATE_RESET_TIME', enabled: settings.dailyResetEnabled });
});

document.getElementById('remindersToggle').addEventListener('change', (e) => {
  settings.reminders = e.target.checked;
  saveSettings();
});

document.getElementById('achievementsToggle').addEventListener('change', (e) => {
  settings.achievements = e.target.checked;
  saveSettings();
});

document.getElementById('streakToggle').addEventListener('change', (e) => {
  settings.streakReminders = e.target.checked;
  saveSettings();
});

document.getElementById('timerStopToggle').addEventListener('change', (e) => {
  settings.timerStopNotification = e.target.checked;
  saveSettings();
});

document.getElementById('milestoneToggle').addEventListener('change', (e) => {
  settings.milestoneNotifications = e.target.checked;
  saveSettings();
});

document.getElementById('floatingTimerToggle').addEventListener('change', (e) => {
  settings.floatingTimer = e.target.checked;
  saveSettings();
  updateFloatingTimer(sessionActive);
  broadcastSettingsChange();
});

document.querySelectorAll('.theme-btn[data-position]').forEach(btn => {
  btn.addEventListener('click', () => {
    settings.floatingTimerPosition = btn.dataset.position;
    saveSettings();
    updateSettingsUI();
    updateFloatingTimer(sessionActive);
    broadcastSettingsChange();
  });
});

function broadcastSettingsChange() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, {
        type: 'TIMER_SETTINGS_CHANGED',
        settings: {
          enabled: settings.floatingTimer,
          position: settings.floatingTimerPosition || 'left'
        }
      }).catch(() => {});
    });
  });
}

document.getElementById('exportDataBtn').addEventListener('click', () => {
  const dataStr = JSON.stringify(studyData, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `rohitks-study-data-${new Date().toISOString().split('T')[0]}.json`;
  link.click();
  URL.revokeObjectURL(url);
});

document.getElementById('resetDataBtn').addEventListener('click', () => {
  if (confirm('⚠️ Are you sure you want to reset ALL data? This cannot be undone!')) {
    if (confirm('This will delete all subjects, progress, and stats. Continue?')) {
      studyData = getDefaultData();
      saveData();
      updateAllUI();
      alert('✅ All data has been reset.');
    }
  }
});

document.getElementById('openSiteBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: settings.siteUrl || 'https://read.rohitks.com.np' });
});

document.getElementById('saveBrandingBtn').addEventListener('click', () => {
  settings.extensionName = document.getElementById('extensionNameInput').value.trim() || 'StudyTimer Pro';
  settings.extensionSubtitle = document.getElementById('extensionSubtitleInput').value.trim() || 'Loksewa Preparation';
  settings.siteName = document.getElementById('siteNameInput').value.trim() || 'Study Site';
  settings.siteUrl = document.getElementById('siteUrlInput').value.trim() || 'https://read.rohitks.com.np';

  saveSettings();
  applyBranding();

  const btn = document.getElementById('saveBrandingBtn');
  const originalText = btn.textContent;
  btn.textContent = '✅ Saved!';
  btn.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';

  setTimeout(() => {
    btn.textContent = originalText;
    btn.style.background = '';
  }, 2000);
});

document.getElementById('refreshBtn').addEventListener('click', (e) => {
  const btn = e.currentTarget;
  btn.classList.add('rotating');
  setTimeout(() => btn.classList.remove('rotating'), 600);
  loadData();
});

// Study Planner functionality
function openPlannerView() {
  document.getElementById('mainView').style.display = 'none';
  document.getElementById('plannerView').style.display = 'block';
  renderPlannerNotes();
}

function closePlannerView() {
  document.getElementById('plannerView').style.display = 'none';
  document.getElementById('mainView').style.display = 'block';
}

function renderPlannerNotes() {
  const list = document.getElementById('plannerNotesList');
  if (!studyData.plannerNotes) {
    studyData.plannerNotes = [];
  }
  
  if (studyData.plannerNotes.length === 0) {
    list.innerHTML = '<div class="empty-state">No notes yet. Add what you want to study!</div>';
    return;
  }
  
  list.innerHTML = studyData.plannerNotes.map(note => {
    const date = new Date(note.createdAt);
    const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    
    return `
      <div class="planner-note ${note.completed ? 'completed' : ''}">
        <button class="planner-check" data-id="${note.id}">
          ${note.completed ? 
            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>' : 
            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle></svg>'
          }
        </button>
        <div class="planner-note-body">
          <p class="planner-note-text">${escapeHtml(note.text)}</p>
          <span class="planner-note-date">${dateStr}</span>
        </div>
        <button class="planner-delete" data-id="${note.id}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
    `;
  }).join('');
  
  attachPlannerListeners();
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function attachPlannerListeners() {
  document.querySelectorAll('.planner-check').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const note = studyData.plannerNotes.find(n => n.id === id);
      if (note) {
        note.completed = !note.completed;
        saveData();
        renderPlannerNotes();
      }
    });
  });
  
  document.querySelectorAll('.planner-delete').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      studyData.plannerNotes = studyData.plannerNotes.filter(n => n.id !== id);
      saveData();
      renderPlannerNotes();
    });
  });
}

function addPlannerNote() {
  const input = document.getElementById('plannerNoteInput');
  const text = input.value.trim();
  if (!text) return;
  
  if (!studyData.plannerNotes) {
    studyData.plannerNotes = [];
  }
  
  studyData.plannerNotes.unshift({
    id: Date.now().toString(),
    text: text,
    completed: false,
    createdAt: new Date().toISOString()
  });
  
  saveData();
  input.value = '';
  renderPlannerNotes();
}

document.getElementById('studyPlannerBtn').addEventListener('click', openPlannerView);
document.getElementById('backToMainBtn').addEventListener('click', closePlannerView);
document.getElementById('addPlannerNoteBtn').addEventListener('click', addPlannerNote);

document.getElementById('plannerNoteInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    addPlannerNote();
  }
});

document.getElementById('saveNotesBtn').addEventListener('click', saveNotes);

document.getElementById('closeNotesBtn').addEventListener('click', closeNotesModal);

document.getElementById('notesModal').addEventListener('click', (e) => {
  if (e.target.id === 'notesModal') {
    closeNotesModal();
  }
});

document.getElementById('startSessionBtn').addEventListener('click', async () => {
  if (!sessionActive) {
    chrome.runtime.sendMessage({ type: 'START_SESSION' }, (response) => {
      if (response.success) {
        sessionActive = true;
        sessionStart = Date.now();
        updateSessionButton(true);
        updateFloatingTimer(true);
        broadcastFloatingTimerState(true);
      }
    });
  } else {
    chrome.runtime.sendMessage({ type: 'STOP_SESSION' }, (response) => {
      if (response.success) {
        sessionActive = false;
        studyData = response.studyData;
        updateSessionButton(false);
        updateFloatingTimer(false);
        broadcastFloatingTimerState(false);
        updateStreak();
        updateStats();
        checkAchievements();
        updateAchievements();
      }
    });
  }
});

document.getElementById('addSubjectBtn').addEventListener('click', () => {
  editingSubjectId = null;
  document.getElementById('modalTitle').textContent = 'Add Subject';
  document.getElementById('subjectNameInput').value = '';
  document.getElementById('subjectModal').classList.add('active');
});

document.getElementById('saveSubjectBtn').addEventListener('click', () => {
  const name = document.getElementById('subjectNameInput').value.trim();
  if (!name) return;

  if (editingSubjectId) {
    const subject = studyData.subjects.find(s => s.id === editingSubjectId);
    if (subject) {
      subject.name = name;
    }
  } else {
    studyData.subjects.push({
      id: Date.now().toString(),
      name,
      progress: 0,
      completed: false
    });
  }

  saveData();
  updateSubjects();
  updateProgress();
  document.getElementById('subjectModal').classList.remove('active');
  editingSubjectId = null;
});

document.getElementById('cancelSubjectBtn').addEventListener('click', () => {
  document.getElementById('subjectModal').classList.remove('active');
  editingSubjectId = null;
});

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));

    tab.classList.add('active');
    const tabName = tab.dataset.tab;
    document.getElementById(tabName + 'Tab').classList.add('active');

    if (tabName === 'bookmarks') {
      updateBookmarks();
    }
  });
});

loadData();
